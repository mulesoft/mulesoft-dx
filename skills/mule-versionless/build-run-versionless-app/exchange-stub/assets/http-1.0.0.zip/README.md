# http (stub versionless connector)

extension-model.json, dsl.json, and the embedded XSD are copied verbatim from go-runtime connectors/http/descriptor/ for local build testing.
