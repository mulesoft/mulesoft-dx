# salesforce (stub versionless connector)

extension-model.json, dsl.json, and the embedded XSD are copied verbatim from go-runtime connectors/salesforce/descriptor/ for local build testing.
