# twilio (stub versionless connector)

extension-model.json, dsl.json, and the embedded XSD are copied verbatim from go-runtime connectors/twilio/descriptor/ for local build testing.
